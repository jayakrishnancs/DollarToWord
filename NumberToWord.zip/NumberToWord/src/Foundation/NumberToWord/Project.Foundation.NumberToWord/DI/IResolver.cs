﻿using System;

namespace Project.Foundation.NumberToWord
{
	public interface IResolver
	{
		object ResolveFromContainer(Type type);
		T ResolveFromContainer<T>();
	}
}
