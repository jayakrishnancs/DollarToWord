﻿using NUnit.Framework;
using System;
using Unity;

namespace Project.Foundation.NumberToWord
{
	public class IoC : IResolver
	{

		#region Singleton implementation
		private static IResolver Instance;
		static IoC()
		{
			Instance = new IoC(null);
		}
		#endregion

		#region Static methods
		public static object Resolve(Type type)
		{
			return Instance.ResolveFromContainer(type);
		}
		public static T Resolve<T>()
		{
			return Instance.ResolveFromContainer<T>();
		}
		public static void SetIoC(IResolver ioc)
		{
			Instance = ioc;
		}
		#endregion

		private readonly IUnityContainer Container;

		public IoC(IUnityContainer container)
		{
			Container = container;
		}

		public object ResolveFromContainer(Type type)
		{
			Assert.IsNotNull(Container, "Call IoC::SetIoC() before resolving");
			return Container.Resolve(type);
		}

		public T ResolveFromContainer<T>()
		{
			Assert.IsNotNull(Container, "Call IoC::SetIoC() before resolving");
			return Container.Resolve<T>();
		}

	}
}