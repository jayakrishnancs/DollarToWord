﻿namespace Project.Foundation.NumberToWord.Repository
{
	public interface INumberToWordRepository
	{
		string ConvertToWords(string Number);
	}
}
