﻿using System;

namespace Project.Foundation.NumberToWord.Repository
{
	public class NumberToWordRepository : INumberToWordRepository
	{
		public NumberToWordRepository()
		{

		}

		public string ConvertToWords(string Number)
		{
			string result = "", fullNo = Number, identifyPoints = "", joiningString = "DOLLARS", decimalString = "";
			string finalString = "";
			try
			{
				int decimalPlace = Number.IndexOf(".");
				if (decimalPlace > 0)
				{
					fullNo = Number.Substring(0, decimalPlace);
					identifyPoints = Number.Substring(decimalPlace + 1);
					if (Convert.ToInt32(identifyPoints) > 0)
					{
						joiningString = "DOLLARS and ";
						finalString = "CENTS " + finalString;
						decimalString = ConvertDecimalsPlaces(identifyPoints);
					}
				}
				result = string.Format("{0} {1}{2} {3}", ConvertWholeNumber(fullNo).Trim(), joiningString, decimalString, finalString);
			}
			catch { }
			return result;
		}

		private static string ConvertWholeNumber(string Number)
		{
			string result = "";
			try
			{
				bool startsWithZero = false;
				bool isValid = false; 
				double checkDouble = (Convert.ToDouble(Number));
				if (checkDouble > 0)
				{
					startsWithZero = Number.StartsWith("0");

					int digitsPosition = Number.Length;
					int position = 0;
					string identifyPlace = "";
					switch (digitsPosition)
					{
						case 1:
							result = IdentifyOnesPlaces(Number);
							isValid = true;
							break;
						case 2:
							result = IdentifyTensPlaces(Number);
							isValid = true;
							break;
						case 3: 
							position = (digitsPosition % 3) + 1;
							identifyPlace = " Hundred AND ";
							break;
						case 4:
						case 5:
						case 6:
							position = (digitsPosition % 4) + 1;
							identifyPlace = " Thousand ";
							break;
						case 7:
						case 8:
						case 9:
							position = (digitsPosition % 7) + 1;
							identifyPlace = " Million ";
							break;
						case 10: 
						case 11:
						case 12:
							position = (digitsPosition % 10) + 1;
							identifyPlace = " Billion ";
							break;
						default:
							isValid = true;
							break;
					}
					if (!isValid)
					{
						if (Number.Substring(0, position) != "0" && Number.Substring(position) != "0")
						{
							try
							{
								result = ConvertWholeNumber(Number.Substring(0, position)) + identifyPlace + ConvertWholeNumber(Number.Substring(position));
							}
							catch { }
						}
						else
						{
							result = ConvertWholeNumber(Number.Substring(0, position)) + ConvertWholeNumber(Number.Substring(position));
						}
					} 
					if (result.Trim().Equals(identifyPlace.Trim())) result = "";
				}
			}
			catch { }
			return result.Trim();
		}

		private static string IdentifyOnesPlaces(string Number)
		{
			int NumberToFind = Convert.ToInt32(Number);
			string result = "";
			switch (NumberToFind)
			{
				case 1:
					result = "One";
					break;
				case 2:
					result = "Two";
					break;
				case 3:
					result = "Three";
					break;
				case 4:
					result = "Four";
					break;
				case 5:
					result = "Five";
					break;
				case 6:
					result = "Six";
					break;
				case 7:
					result = "Seven";
					break;
				case 8:
					result = "Eight";
					break;
				case 9:
					result = "Nine";
					break;
			}
			return result;
		}

		private static string IdentifyTensPlaces(string Number)
		{
			int NumberToFind = Convert.ToInt32(Number);
			string result = null;
			switch (NumberToFind)
			{
				case 10:
					result = "Ten";
					break;
				case 11:
					result = "Eleven";
					break;
				case 12:
					result = "Twelve";
					break;
				case 13:
					result = "Thirteen";
					break;
				case 14:
					result = "Fourteen";
					break;
				case 15:
					result = "Fifteen";
					break;
				case 16:
					result = "Sixteen";
					break;
				case 17:
					result = "Seventeen";
					break;
				case 18:
					result = "Eighteen";
					break;
				case 19:
					result = "Nineteen";
					break;
				case 20:
					result = "Twenty";
					break;
				case 30:
					result = "Thirty";
					break;
				case 40:
					result = "Fourty";
					break;
				case 50:
					result = "Fifty";
					break;
				case 60:
					result = "Sixty";
					break;
				case 70:
					result = "Seventy";
					break;
				case 80:
					result = "Eighty";
					break;
				case 90:
					result = "Ninety";
					break;
				default:
					if (NumberToFind > 0)
					{
						result = IdentifyTensPlaces(Number.Substring(0, 1) + "0") + " " + IdentifyOnesPlaces(Number.Substring(1));
					}
					break;
			}
			return result;
		}

		private static string ConvertDecimalsPlaces(string number)
		{
			return IdentifyTensPlaces(number);
		}
	}
}