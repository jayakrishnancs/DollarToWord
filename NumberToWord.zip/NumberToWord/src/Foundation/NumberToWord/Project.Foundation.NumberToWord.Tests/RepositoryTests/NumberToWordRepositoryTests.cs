﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Project.Foundation.NumberToWord.Repository;

namespace Project.Foundation.NumberToWord.Tests.RepositoryTests
{
	[TestClass]
	public class NumberToWordRepositoryTests
	{
		private NumberToWordRepository _numberToWordRepository;

		[TestInitialize]
		public void Setup()
		{
			_numberToWordRepository = new NumberToWordRepository();
			Assert.IsNotNull(_numberToWordRepository);
		}

		[TestMethod]
		public void NumberToWordRepository_ConvertToWords_ValidResult()
		{
			var result = _numberToWordRepository.ConvertToWords("123.45") as string;
			Assert.IsNotNull(result);
			Assert.AreEqual("ONE HUNDRED AND TWENTY THREE DOLLARS AND FOURTY FIVE CENTS", result);
		}

		[TestMethod]
		public void NumberToWordRepository_ConvertToWords_Minus()
		{
			var result = _numberToWordRepository.ConvertToWords("-123.45") as string;
			Assert.IsNotNull(result);
			Assert.AreEqual(" DOLLARS and Fourty Five CENTS ", result);
		}

		[TestMethod]
		public void NumberToWordRepository_ConvertToWords_Zero()
		{
			var result = _numberToWordRepository.ConvertToWords("0") as string;
			Assert.IsNotNull(result);
		}
	}
}
