﻿using Project.Foundation.NumberToWord;
using Project.Foundation.NumberToWord.Repository;
using System;
using System.Web.Mvc;

namespace Project.NumberToWord.Controllers
{
	public class HomeController : Controller
	{
		private readonly INumberToWordRepository _NumberToWordRepository;

		public HomeController() : this(IoC.Resolve<INumberToWordRepository>()) { }
		public HomeController(INumberToWordRepository NumberToWordRepository) { _NumberToWordRepository = NumberToWordRepository; }

		public ActionResult Index()
		{
			return View();
		}
		[HttpPost]
		public ActionResult ConvertToWord(string number)
		{
			string numberToCheck = Convert.ToDouble(number).ToString("F" + 2);
			string negativeCheck = "";
			string result;

			if (numberToCheck.Contains("-"))
			{
				negativeCheck = "Minus ";
				numberToCheck = numberToCheck.Substring(1, number.Length - 1);
			}
			if (number == "0")
			{
				result = "Entered number in currency fomat is Zero";
			}
			else
			{
				result = negativeCheck + _NumberToWordRepository.ConvertToWords(numberToCheck);
			}
			return Json(new { Result = result.ToUpper() });
		}
	}
}