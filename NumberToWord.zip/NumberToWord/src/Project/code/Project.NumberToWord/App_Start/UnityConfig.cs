﻿using Project.Foundation.NumberToWord;
using Project.Foundation.NumberToWord.Repository;
using Unity;
using Unity.Lifetime;

namespace Project.NumberToWord.App_Start
{
	internal static class UnityConfig
	{
		private static class Lifetime
		{
			internal static LifetimeManager Singleton { get { return new ContainerControlledLifetimeManager(); } }
			internal static LifetimeManager Transient { get { return new TransientLifetimeManager(); } }
		}

		public static void Configure()
		{
			var container = new UnityContainer();
			RegisterTypes(container);

			MvcUnityContainer.Container = container;

			var ioc = new IoC(container);
			IoC.SetIoC(ioc);

		}

		private static void RegisterTypes(IUnityContainer container)
		{
			container.RegisterType<INumberToWordRepository, NumberToWordRepository>();
		}
	}
}