﻿using Unity;

namespace Project.NumberToWord.App_Start
{
	public static class MvcUnityContainer
	{
		public static IUnityContainer Container { get; set; }
	}
}