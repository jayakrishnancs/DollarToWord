﻿$(document).ready(function () {
	$("#btnConvertNumber").click(function () {
		var spinnerBorder = $('.spinner-border');
		spinnerBorder.css('display', 'flex');
		$.ajax({
			type: 'POST',
			url: '/Home/ConvertToWord',
			data: JSON.stringify({number: $('#txtNumber').val() }),
			success: function (response) {
				$('#divResult').html(response.Result);
				spinnerBorder.css('display', 'none');
			},
			contentType: "application/json",
			dataType: 'json'
		});
	});
});