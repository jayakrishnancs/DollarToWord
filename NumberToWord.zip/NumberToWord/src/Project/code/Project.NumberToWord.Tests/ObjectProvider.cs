﻿using Moq;
using Project.Foundation.NumberToWord.Repository;
using Project.NumberToWord.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.NumberToWord.Tests
{
	internal static class ObjectProvider
	{
		public static HomeController CreateHomeController()
		{
			return new HomeController(CreateMockNumberToWordRepository());
		}

		public static INumberToWordRepository CreateMockNumberToWordRepository()
		{
			var svc = new Mock<INumberToWordRepository>();
			svc.Setup(s => s.ConvertToWords("123.45")).Returns("ONE HUNDRED AND TWENTY THREE DOLLARS AND FOURTY FIVE CENTS");
			return svc.Object;
		}
	}
}
