﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Project.NumberToWord.Controllers;

namespace Project.NumberToWord.Tests.Controllers
{
	[TestClass]
	public class HomeControllerTests
	{
		private HomeController _homeController;

		[TestInitialize]
		public void Setup()
		{
			_homeController = ObjectProvider.CreateHomeController();
			Assert.IsNotNull(_homeController);
		}

		[TestMethod]
		public void HomeController_Index()
		{
			var result = _homeController.Index() as ViewResult;
			
			Assert.AreEqual("", result.ViewName);
		}

		[TestMethod]
		public void HomeController_ConvertToWord()
		{
			var result = _homeController.ConvertToWord("123.45") as JsonResult;
			string jsonResult = GetValueFromJsonResult<string>(result, "Result");

			Assert.IsNotNull(jsonResult);
			Assert.AreEqual("ONE HUNDRED AND TWENTY THREE DOLLARS AND FOURTY FIVE CENTS", jsonResult);
		}

		[TestMethod]
		public void HomeController_ConvertToWord_MinusCheck()
		{
			var result = _homeController.ConvertToWord("-123.45") as JsonResult;
			string jsonResult = GetValueFromJsonResult<string>(result, "Result");

			Assert.IsNotNull(jsonResult);
			Assert.AreEqual("MINUS ONE HUNDRED AND TWENTY THREE DOLLARS AND FOURTY FIVE CENTS", jsonResult);
		}

		[TestMethod]
		public void HomeController_ConvertToWord_ZeroCheck()
		{
			var result = _homeController.ConvertToWord("0") as JsonResult;
			string jsonResult = GetValueFromJsonResult<string>(result, "Result");

			Assert.IsNotNull(jsonResult);
			Assert.AreEqual("ENTERED NUMBER IN CURRENCY FOMAT IS ZERO", jsonResult);
		}

		private T GetValueFromJsonResult<T>(JsonResult jsonResult, string propertyName)
		{
			var property =
				jsonResult.Data.GetType().GetProperties()
				.Where(p => string.Compare(p.Name, propertyName) == 0)
				.FirstOrDefault();

			if (null == property)
				throw new ArgumentException("propertyName not found", "propertyName");
			return (T)property.GetValue(jsonResult.Data, null);
		}
	}
}
